#include <iostream>
#include <vector>
#include <string>
#include <sstream>
#include <cctype>
#include <map>

using namespace std;

// Parse a polynomial like "3x^2 + 2x - 5" into terms
map<int, int> parsePolynomial(const string& input) {
    map<int, int> terms;
    istringstream iss(input);
    string token;
    int sign = 1;

    while (iss >> token) {
        if (token == "+") {
            sign = 1;
            continue;
        } else if (token == "-") {
            sign = -1;
            continue;
        }

        int coeff = 0, power = 0;
        size_t xPos = token.find('x');

        if (xPos == string::npos) {
            coeff = stoi(token);
            power = 0;
        } else {
            coeff = (xPos == 0) ? 1 : stoi(token.substr(0, xPos));
            size_t powPos = token.find('^');
            if (powPos != string::npos)
                power = stoi(token.substr(powPos + 1));
            else
                power = 1;
        }

        terms[power] += coeff * sign;
    }

    return terms;
}

// Differentiate the polynomial
map<int, int> differentiate(const map<int, int>& terms) {
    map<int, int> derivative;
    for (auto& [power, coeff] : terms) {
        if (power > 0) {
            derivative[power - 1] = coeff * power;
        }
    }
    return derivative;
}

// Convert polynomial map to string
string toString(const map<int, int>& poly) {
    ostringstream oss;
    bool first = true;
    for (auto it = poly.rbegin(); it != poly.rend(); ++it) {
        int coeff = it->second;
        int power = it->first;
        if (coeff == 0) continue;

        if (!first && coeff > 0)
            oss << " + ";
        else if (coeff < 0)
            oss << " - ";

        coeff = abs(coeff);
        if (power == 0) oss << coeff;
        else if (power == 1) oss << (coeff == 1 ? "x" : to_string(coeff) + "x");
        else oss << (coeff == 1 ? "x^" + to_string(power) : to_string(coeff) + "x^" + to_string(power));

        first = false;
    }
    return oss.str().empty() ? "0" : oss.str();
}

int main() {
    string input;
    cout << "Enter a polynomial (e.g., 3x^2 + 2x - 5): ";
    getline(cin, input);

    auto terms = parsePolynomial(input);
    auto derivative = differentiate(terms);

    cout << "Derivative: " << toString(derivative) << endl;
    return 0;
}
